'use strict'

module.exports = (a) => console.log(JSON.stringify(a, null, 2))
