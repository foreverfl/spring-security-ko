'use strict'

module.exports = (a) => a !== null
